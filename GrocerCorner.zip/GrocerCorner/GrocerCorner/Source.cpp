#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

class ItemTracker {
private: map<string, int> itemFrequencyMap;

public:
	ItemTracker() {
		//Read input file and update them frequency map
		ifstream
			inputFile("CS210_Project_Three_Input_File.txt");
		if (inputFile.is_open()) {
			string item;
			while (inputFile >> item) {
				itemFrequencyMap[item]++;

			}
			inputFile.close();
		}
	}
	//Method to search for item frequency
	int searchItemFrequency(const string& item) {
		return itemFrequencyMap[item];
	}

	//Method to print items
	void printAllItems() {
		for (const auto& pair : itemFrequencyMap) {
			cout << pair.first << " " << pair.second << endl;
		}
	}

	//Method to print the Histogram of the frequency for all items
	void printHistogramForItems() {
		for (const auto& pair : itemFrequencyMap) {
			cout << pair.first << " ";
			for (int i = 0; i < pair.second; ++i) {
				cout << "*";
			}
			cout << endl;
		}
	}

	//Method to create a backup file in frequency.dat
	void createBackUpFile() {
		ofstream backupFile("frequency.dat");
		if (backupFile.is_open()) {
			for (const auto& pair : itemFrequencyMap) {
				backupFile << pair.first << " " << pair.second << endl;
			}
			backupFile.close();
			cout << "Backup file created successfully." << endl;
		}
	}
};

int main() {
	ItemTracker itemTracker;

	int choice;
	do {
		cout << "Menu Options:" << endl;
		cout << "1. Search for an item's frequency" << endl;
		cout << "2. Print the list of all items and their frequencies" << endl;
		cout << "3. Print a histogram of item frequencies" << endl;
		cout << "4. Save frequency data to a file" << endl;
		cout << "5. Exit the program" << endl;
		cout << "Enter your choice (1-5): ";
		cin >> choice;

		switch (choice) {
		case 1: {
			string item;
			cout << "Enter the item to search: ";
			cin >> item;
			int Frequency = itemTracker.searchItemFrequency(item);
			cout << "Frequency of " << item << ": " << Frequency << endl;
			break;
		}
		case 2:
			itemTracker.printAllItems();
			break;
		case 3:
			itemTracker.printHistogramForItems();
			break;
		case 4:
			itemTracker.createBackUpFile();
			break;
		case 5:
			cout << "Exiting the program. Goodbye!" << endl;
			break;
		default:
			cout << "Invalid choice. Please try again." << endl;
			break;
		}
		cout << endl;
	} while (choice != 5);

	return 0;
}

